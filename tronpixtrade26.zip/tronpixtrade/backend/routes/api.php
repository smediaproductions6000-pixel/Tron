<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

// ============================================
// PUBLIC/NON-AUTHENTICATED ROUTES
// ============================================

// Authentication routes
Route::post('/register', [\App\Http\Controllers\AuthController::class, 'register']);
Route::post('/login', [\App\Http\Controllers\AuthController::class, 'login']);
Route::post('/forgot-password', [\App\Http\Controllers\AuthController::class, 'forgotPassword']);
Route::post('/password-reset', [\App\Http\Controllers\AuthController::class, 'resetPassword']);
Route::post('/email/verification-notification', [\App\Http\Controllers\AuthController::class, 'resendVerificationEmail']);
Route::get('/email/verify/{id}/{hash}', [\App\Http\Controllers\AuthController::class, 'verifyEmail'])
     ->name('verification.verify');

// CSRF token endpoint
Route::get('/csrf-token', function (Request $request) {
    return response()->json(['csrf_token' => csrf_token()]);
})->middleware('web');

// Public market routes
Route::get('/markets', [\App\Http\Controllers\MarketController::class, 'index']);
Route::get('/markets/{symbol}', [\App\Http\Controllers\MarketController::class, 'show']);
Route::get('/markets/categories', [\App\Http\Controllers\MarketController::class, 'categories']);

// Public traders list
Route::get('/traders', [\App\Http\Controllers\TraderController::class, 'index']);
Route::get('/traders/{id}', [\App\Http\Controllers\TraderController::class, 'show']);

// Health check
Route::get('/health', function () {
    return response()->json(['status' => 'ok'], 200);
});

// ============================================
// AUTHENTICATED ROUTES (auth:sanctum)
// ============================================

Route::middleware('auth:sanctum')->group(function () {

    // User profile
    Route::get('/user', function (Request $request) {
        return $request->user();
    });
    Route::post('/logout', [\App\Http\Controllers\AuthController::class, 'logout']);
    Route::post('/profile/update', [\App\Http\Controllers\UserController::class, 'updateProfile']);
    Route::post('/password/change', [\App\Http\Controllers\UserController::class, 'changePassword']);

    // -------- WALLET ROUTES --------
    Route::get('/wallets', [\App\Http\Controllers\WalletController::class, 'index']);
    Route::post('/wallets', [\App\Http\Controllers\WalletController::class, 'store']);
    Route::get('/wallets/{id}', [\App\Http\Controllers\WalletController::class, 'show']);
    Route::put('/wallets/{id}', [\App\Http\Controllers\WalletController::class, 'update']);

    // -------- TRANSACTION ROUTES --------
    Route::get('/transactions', [\App\Http\Controllers\TransactionController::class, 'index']);
    Route::get('/transactions/{id}', [\App\Http\Controllers\TransactionController::class, 'show']);
    Route::get('/transactions/statistics', [\App\Http\Controllers\TransactionController::class, 'statistics']);

    // -------- CARD ROUTES --------
    Route::get('/cards', [\App\Http\Controllers\CardController::class, 'index']);
    Route::post('/cards', [\App\Http\Controllers\CardController::class, 'store']);
    Route::get('/cards/{id}', [\App\Http\Controllers\CardController::class, 'show']);
    Route::put('/cards/{id}', [\App\Http\Controllers\CardController::class, 'update']);
    Route::delete('/cards/{id}', [\App\Http\Controllers\CardController::class, 'destroy']);
    Route::patch('/cards/{id}/status', [\App\Http\Controllers\CardController::class, 'toggleStatus']);

    // -------- WITHDRAWAL ROUTES --------
    Route::get('/withdrawals', [\App\Http\Controllers\WithdrawalController::class, 'index']);
    Route::post('/withdrawals', [\App\Http\Controllers\WithdrawalController::class, 'store']);
    Route::get('/withdrawals/{id}', [\App\Http\Controllers\WithdrawalController::class, 'show']);
    Route::post('/withdrawals/verify-pin', [\App\Http\Controllers\WithdrawalController::class, 'verifyPin']);
    Route::put('/withdrawals/{id}/status', [\App\Http\Controllers\WithdrawalController::class, 'updateStatus'])->middleware('admin');

    // -------- BROKER WITHDRAWALS --------
    Route::post('/admin/broker-withdrawals', [\App\Http\Controllers\BrokerWithdrawalController::class, 'store']);

    // -------- BROKER TRANSFERS --------
    Route::post('/api/admin/broker-transfers', [\App\Http\Controllers\BrokerTransferController::class, 'store']);

    // -------- BROKER KYC --------
    Route::post('/api/admin/broker-users/kyc/submit', [\App\Http\Controllers\BrokerKYCController::class, 'submit']);
    Route::get('/api/admin/broker-users', [\App\Http\Controllers\BrokerKYCController::class, 'index']);
    Route::post('/api/admin/broker-users/{id}/kyc/approve', [\App\Http\Controllers\BrokerKYCController::class, 'approve']);
    Route::post('/api/admin/broker-users/{id}/kyc/reject', [\App\Http\Controllers\BrokerKYCController::class, 'reject']);
    Route::post('/api/admin/broker-users/{id}/kyc/delete', [\App\Http\Controllers\BrokerKYCController::class, 'delete']);
    Route::post('/api/admin/broker-users/credit', [\App\Http\Controllers\BrokerUserController::class, 'credit']);
    Route::post('/api/admin/broker-users/deduct', [\App\Http\Controllers\BrokerUserController::class, 'deduct']);

    // -------- INVESTMENT PLANS (BROKER/USER) --------
    Route::get('/api/admin/broker-plans', [\App\Http\Controllers\BrokerPlanController::class, 'index']);

    // -------- SECURITY STEPS --------
    Route::get('/security-steps', [\App\Http\Controllers\SecurityStepController::class, 'index']);
    Route::post('/security-steps/{id}/verify', [\App\Http\Controllers\SecurityStepController::class, 'verify']);

    // -------- ADMIN ROUTES --------
    Route::middleware('admin')->group(function () {
        Route::get('/admin/statistics', [\App\Http\Controllers\AdminController::class, 'statistics']);
        Route::get('/admin/users', [\App\Http\Controllers\AdminController::class, 'users']);
        Route::get('/admin/kyc', [\App\Http\Controllers\AdminController::class, 'kyc']);
    });
});