<?php

namespace App\Http\Controllers;

use App\Models\BrokerTransaction;
use App\Models\BrokerUser;
use Illuminate\Http\Request;

class BrokerTransactionController extends Controller
{
    public function index(Request $request)
    {
        $query = BrokerTransaction::query();

        if ($request->has('type')) {
            $query->where('type', $request->type);
        }

        return $query->get();
    }

    public function show($id)
    {
        return BrokerTransaction::findOrFail($id);
    }

    public function statistics()
    {
        $total = BrokerTransaction::sum('amount');
        $pending = BrokerTransaction::where('status', 'pending')->sum('amount');
        $completed = BrokerTransaction::where('status', 'completed')->sum('amount');
        return response()->json(compact('total', 'pending', 'completed'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'broker_user_id' => 'required|exists:broker_users,id',
            'type' => 'required|string',
            'amount' => 'required|numeric',
            'currency' => 'string|max:10',
            'status' => 'string|in:pending,completed,failed',
        ]);

        $transaction = BrokerTransaction::create($request->all());
        return response()->json($transaction, 201);
    }
}