<?php

namespace App\Http\Controllers;

use App\Http\Requests\VerifySecurityStepRequest;
use App\Models\SecurityStep;
use Illuminate\Http\JsonResponse;

class SecurityStepController extends ApiController
{
    /**
     * List security steps for authenticated user
     */
    public function index(): JsonResponse
    {
        try {
            $steps = SecurityStep::where('user_id', auth()->id())
                ->latest()
                ->paginate(15);

            return $this->successWithPagination($steps, 'Security steps retrieved successfully');
        } catch (\Exception $e) {
            return $this->error('Failed to retrieve security steps: ' . $e->getMessage(), 500);
        }
    }

    /**
     * Verify security code
     */
    public function verify(VerifySecurityStepRequest $request, $id): JsonResponse
    {
        try {
            $step = SecurityStep::find($id);

            if (!$step) {
                return $this->notFound('Security step not found');
            }

            // Check authorization
            if ($step->user_id !== auth()->id() && !auth()->user()->is_admin) {
                return $this->forbidden('You do not have access to this security step');
            }

            // Verify the code
            if ($step->verification_code === $request->code) {
                $step->update(['is_verified' => true, 'verified_at' => now()]);
                return $this->success(['step' => $step], 'Security step verified successfully');
            }

            return $this->error('Invalid verification code', 422);
        } catch (\Exception $e) {
            return $this->error('Failed to verify security step: ' . $e->getMessage(), 500);
        }
    }
}
