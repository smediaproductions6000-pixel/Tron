<script setup lang="ts">
import { ref } from 'vue'
import AppLogo from '@/components/AppLogo.vue'
import { Mail, Phone, MapPin } from 'lucide-vue-next'

// Contact form state
const form = ref({
  name: '',
  email: '',
  subject: '',
  message: ''
})

const submitting = ref(false)
const success = ref(false)

// Simulate form submission
const submitForm = async () => {
  if (!form.value.name || !form.value.email || !form.value.subject || !form.value.message) return
  submitting.value = true
  await new Promise(r => setTimeout(r, 1200))
  submitting.value = false
  success.value = true
  form.value = { name: '', email: '', subject: '', message: '' }
}

// Floating orbs
const orbs = Array.from({ length: 12 }, (_, i) => ({
  id: i,
  top: Math.random() * 80 + '%',
  left: Math.random() * 90 + '%',
  size: 40 + Math.random() * 80,
  color: ['#0f0', '#0fa', '#0c0', '#0ff', '#0f6'][i % 5],
  class: `orb-${i % 2 === 0 ? 'up' : 'down'}`,
  duration: 12 + Math.random() * 10 + 's',
}))
</script>

<template>
  <div class="relative bg-black min-h-screen text-white overflow-hidden">

    <!-- Floating Orbs -->
    <div class="absolute inset-0 pointer-events-none">
      <div 
        v-for="orb in orbs"
        :key="orb.id"
        :class="`absolute rounded-full opacity-20 ${orb.class}`"
        :style="{
          width: orb.size + 'px',
          height: orb.size + 'px',
          top: orb.top,
          left: orb.left,
          backgroundColor: orb.color,
          animationDuration: orb.duration
        }"
      ></div>
    </div>

    <!-- Header -->
    <header class="sticky top-0 z-50 bg-black/80 backdrop-blur-md shadow-md px-6 py-4 flex items-center justify-between">
      <div class="flex items-center gap-2">
        <AppLogo class="w-8 h-8 drop-shadow-[0_0_12px_hsl(160,100%,50%)] animate-glow-logo"/>
        <span class="font-bold text-lg">TronpixTrades</span>
      </div>
      <nav class="flex gap-4">
        <router-link to="/" class="hover:text-green-400 transition-colors">Home</router-link>
        <router-link to="/about" class="hover:text-green-400 transition-colors">About</router-link>
        <router-link to="/contact" class="text-green-400 font-semibold">Contact</router-link>
        <router-link to="/login" class="hover:text-green-400 transition-colors">Login</router-link>
      </nav>
    </header>

    <!-- Hero / Intro -->
    <section class="text-center py-24 px-6 lg:px-20 relative z-10">
      <h1 class="text-4xl md:text-5xl font-bold mb-4">Contact Us</h1>
      <p class="text-gray-400 max-w-2xl mx-auto text-sm md:text-base">
        Have questions, suggestions, or need assistance? Reach out to us via the form or our contact info below.
      </p>
    </section>

    <!-- Contact Info & Form -->
    <section class="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 px-6 lg:px-20 relative z-10 pb-24">

      <!-- Contact Info -->
      <div class="glass p-6 rounded-2xl shadow-lg flex flex-col gap-6">
        <div class="flex items-start gap-4">
          <MapPin class="w-6 h-6 text-green-400 mt-1"/>
          <div>
            <h3 class="font-semibold text-white mb-1">Address</h3>
            <p class="text-gray-300 text-sm">123 Trading Ave, Lagos, Nigeria</p>
          </div>
        </div>
        <div class="flex items-start gap-4">
          <Phone class="w-6 h-6 text-green-400 mt-1"/>
          <div>
            <h3 class="font-semibold text-white mb-1">Phone</h3>
            <p class="text-gray-300 text-sm">+234 800 123 4567</p>
          </div>
        </div>
        <div class="flex items-start gap-4">
          <Mail class="w-6 h-6 text-green-400 mt-1"/>
          <div>
            <h3 class="font-semibold text-white mb-1">Email</h3>
            <p class="text-gray-300 text-sm">support@tronpixtrades.com</p>
          </div>
        </div>
      </div>

      <!-- Contact Form -->
      <form
        class="glass p-6 rounded-2xl shadow-lg flex flex-col gap-4"
        @submit.prevent="submitForm"
      >
        <input 
          v-model="form.name"
          type="text"
          placeholder="Full Name"
          class="input"
          required
        />
        <input 
          v-model="form.email"
          type="email"
          placeholder="Email Address"
          class="input"
          required
        />
        <input 
          v-model="form.subject"
          type="text"
          placeholder="Subject"
          class="input"
          required
        />
        <textarea
          v-model="form.message"
          placeholder="Your Message"
          rows="5"
          class="input"
          required
        ></textarea>

        <button
          type="submit"
          class="w-full bg-green-500 text-black p-3 rounded-xl font-semibold disabled:opacity-50"
          :disabled="submitting"
        >
          {{ submitting ? 'Sending...' : 'Send Message' }}
        </button>

        <p v-if="success" class="text-green-400 text-sm mt-2">Message sent successfully!</p>
      </form>

    </section>

  </div>
</template>

<style scoped>
/* Glow animation for AppLogo */
@keyframes glow-logo {
  0%, 100% { filter: drop-shadow(0 0 8px hsl(160,100%,50%)); }
  50% { filter: drop-shadow(0 0 14px hsl(160,100%,50%)); }
}
.animate-glow-logo { animation: glow-logo 2s ease-in-out infinite; }

/* Orb float animations */
@keyframes orb-up {
  0% { transform: translateY(0) translateX(0); opacity: 0.15; }
  50% { transform: translateY(-120px) translateX(30px); opacity: 0.3; }
  100% { transform: translateY(0) translateX(0); opacity: 0.15; }
}
@keyframes orb-down {
  0% { transform: translateY(0) translateX(0); opacity: 0.15; }
  50% { transform: translateY(120px) translateX(-30px); opacity: 0.3; }
  100% { transform: translateY(0) translateX(0); opacity: 0.15; }
}
.orb-up { animation: orb-up linear infinite alternate; }
.orb-down { animation: orb-down linear infinite alternate; }

/* Glass card style */
.glass {
  background: linear-gradient(135deg, rgba(0,255,0,0.05), rgba(0,255,0,0.15));
  background-color: hsl(0 0% 0% / 0.35);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
  border-radius: 1.5rem;
  border: 1px solid hsl(120 60% 50% / 0.2);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.glass:hover { transform: translateY(-4px) scale(1.02); box-shadow: 0 0 40px rgba(0,255,0,0.3); }

/* Input fields */
.input {
  width: 100%;
  padding: 12px 16px;
  border-radius: 12px;
  background: rgba(255,255,255,0.05);
  border: 1px solid rgba(255,255,255,0.1);
  outline: none;
  color: white;
  resize: none;
}
.input::placeholder { color: rgba(255,255,255,0.5); }
</style>